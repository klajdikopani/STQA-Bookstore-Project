package com.example.bookstorehenrihatija.ui;

import javafx.scene.control.Button;

public class SearchButton extends Button {
    public SearchButton() {
        super.setText("Search");
    }
}
