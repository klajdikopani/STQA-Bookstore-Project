package com.example.bookstorehenrihatija.models;

import com.example.bookstorehenrihatija.auxiliaries.FileHandler;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class User extends BaseModel implements Serializable {
    private static final ArrayList<User> users = new ArrayList<>();
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String email;
    private double salary;
    private Role role;
    public static final String FILE_PATH = "./data/users.ser";
    public static final File DATA_FILE = new File(FILE_PATH);
    @Serial
    private static final long serialVersionUID = 1234567L;
    public User(){}
    public User(String username, String password, String firstName, String lastName,
                String email, double salary, Role role) {
        this(username, password);
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.salary = salary;
        this.role = role;
    }
    public User(String username, String password){
        this.username = username;
        this.password = password;
    }
    public String getFirstName(){ return firstName; }
    public void setFirstName(String firstName){ this.firstName = firstName; }
    public String getLastName(){ return lastName; }
    public void setLastName(String lastName){ this.lastName = lastName; }
    public String getEmail(){ return email; }
    public void setEmail(String email){ this.email = email; }
    public double getSalary(){ return salary; }
    public void setSalary(double salary){ this.salary = salary; }
    public String getUsername(){ return username; }
    public void setUsername(String username){ this.username = username; }
    public String getPassword(){ return password; }
    public void setPassword(String password){ this.password = password; }
    public Role getRole(){ return role; }
    public void setRole(Role role){ this.role = role; }
    @Override
    public String toString(){
        return "User{" +
                "username=" + getUsername() +
                ", password=" + getPassword() +
                ", role=" + getRole() +
                '}';
    }
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof User) {
            User other = (User) obj;
            return other.getUsername().equals(getUsername()) && other.getPassword().equals(getPassword());
        }
        return false;
    }
    public static User getIfExists(User potentialUser){
        for(User user : getUsers()){
            if(user.equals(potentialUser)){
                return user;
            }
        }
        return null;
    }
    public static ArrayList<User> getUsers(){
        if(users.size() == 0){
            try{
                ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(FILE_PATH));
                while(true){
                    User temp = (User) inputStream.readObject();
                    if(temp != null){
                        users.add(temp);
                    }else{
                        break;
                    }
                }

                inputStream.close();
            }catch(EOFException eofException){
                System.out.println("End of file reached!");
            }catch(IOException | ClassNotFoundException e){
                e.printStackTrace();
            }
        }
        return users;
    }
    @Override
    public boolean SaveInFile() {
        boolean saved = super.save(DATA_FILE);
        if(saved)
            users.add(this);
        return saved;
    }

    @Override
    public boolean isValid() {
        return getUsername().length() > 0
                && getPassword().length() > 0
                && getFirstName().length() > 0
                && getLastName().length() > 0
                && getEmail().length() > 0
                && getSalary() > 0;
    }

    @Override
    public boolean deleteFromFile() {
        users.remove(this);
        try{
            FileHandler.overwriteCurrentListToFile(DATA_FILE, users);
        }catch(IOException ex){
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public static ArrayList<User> getSearchResults(String searchText){
        if(searchText.equals(""))
            return User.getUsers();
        ArrayList<User> results = new ArrayList<>();
        for(User user: User.getUsers()){
            if(user.getUsername().equals(searchText)
                    || user.getFirstName().equals(searchText)
                    || user.getLastName().equals(searchText)
                    || (user.getFirstName() + " " + user.getLastName()).equals(searchText))
                results.add(user);
        }
        return results;
    }
}
