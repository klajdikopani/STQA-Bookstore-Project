package com.example.bookstorehenrihatija.models;

import com.example.bookstorehenrihatija.auxiliaries.FileHandler;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.SimpleTimeZone;

public class Book extends BaseModel implements Serializable {
    private String isbn;
    private String title;
    private float purchasedPrice;
    private float sellingPrice;
    private Author author;
    private int count;
    public static final String FILE_PATH = "./data/books.ser";
    public static final File DATA_FILE = new File(FILE_PATH);
    @Serial
    private static final long serialVersionUID = 1234567L;
    private static final ArrayList<Book> books = new ArrayList<>();
    public Book(){}
    public Book(String isbn, String title, float purchasedPrice, float sellingPrice, Author author, int count){
        this.isbn = isbn;
        this.title = title;
        this.purchasedPrice = purchasedPrice;
        this.sellingPrice = sellingPrice;
        this.author = author;
        this.count = count;
    }
    public float getPurchasedPrice(){ return  purchasedPrice; }
    public void setPurchasedPrice(float purchasedPrice){ this.purchasedPrice = purchasedPrice; }
    public float getSellingPrice(){return sellingPrice; }
    public void setSellingPrice(float sellingPrice){ this.sellingPrice = sellingPrice; }
    public String getIsbn(){ return isbn; }
    public void setIsbn(String isbn){ this.isbn = isbn; }
    public String getTitle(){ return title; }
    public void setTitle(String title){ this.title = title; }

    public Author getAuthor() {
        return author;
    }
    public void setAuthor(Author author){ this.author = author; }
    public int getCount(){ return count; }
    public void setCount(int count){ this.count = count; }

    public static ArrayList<Book> getSearchResults(String searchText){
        ArrayList<Book> searchResults = new ArrayList<>();
        for(Book book : Book.getBooks()){
            if(book.getTitle().equals(searchText)){
                searchResults.add(book);
            }
        }
        return searchResults;
    }

    @Override
    public boolean SaveInFile() {
        boolean saved = super.save(DATA_FILE);
        if(saved)
            books.add(this);
        return saved;
    }

    @Override
    public boolean isValid() {
        return isbn.length() == 13 &&
                title.length() > 0 &&
                purchasedPrice > 0 &&
                sellingPrice > 0 &&
                author != null;
    }

    @Override
    public boolean deleteFromFile() {
        books.remove(this);
        try{
            FileHandler.overwriteCurrentListToFile(DATA_FILE, books);
        }catch (IOException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static ArrayList<Book> getBooks(){
        if(books.size() == 0){
            try {
                ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(FILE_PATH));
                while (true) {
                    Book temp = (Book) inputStream.readObject();
                    if (temp != null) {
                        books.add(temp);
                    } else
                        break;
                }
                inputStream.close();
            }catch (EOFException eofException){
                System.out.println("End of book file reached!");
            }catch(IOException | ClassNotFoundException ex){
                ex.printStackTrace();
            }
        }
        return books;
    }
}
