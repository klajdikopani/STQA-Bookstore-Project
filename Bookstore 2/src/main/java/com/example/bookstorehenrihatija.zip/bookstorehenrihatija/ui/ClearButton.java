package com.example.bookstorehenrihatija.ui;

import javafx.scene.control.Button;

public class ClearButton extends Button {
    public ClearButton(){
        super.setText("Clear");
    }
}
